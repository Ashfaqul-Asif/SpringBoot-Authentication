package com.example.demo.model;

public enum Status {
    TODO,
    IN_PROGRESS,
    COMPLETED,
    DONE

}
