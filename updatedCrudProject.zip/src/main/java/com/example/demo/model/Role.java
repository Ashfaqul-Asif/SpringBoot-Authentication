package com.example.demo.model;

public enum Role {
    ADMIN_USER,
    REGULAR_USER,
}
