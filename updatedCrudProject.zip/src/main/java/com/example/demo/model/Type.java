package com.example.demo.model;

public enum Type {
    ARTICLE,
    VIDEO,
    COURSE,
    CONFERENCE_TALK
}
